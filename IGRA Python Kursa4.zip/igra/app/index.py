import random
import sys

from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QTableWidgetItem, QInputDialog, QFileDialog, QDialog, QDialogButtonBox, QVBoxLayout, QLabel, \
    QPushButton

import mainwindow


class CustomDialog(QDialog):
    def __init__(self, parent_window, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Подтвердите")

        button1 = QPushButton('Я', self)
        button2 = QPushButton('Компьютер', self)

        self.setWindowModality(QtCore.Qt.ApplicationModal)
        self.layout = QVBoxLayout()
        message = QLabel("Кто ходит первым?")
        self.layout.addWidget(message)
        self.layout.addWidget(button1)
        self.layout.addWidget(button2)
        self.setLayout(self.layout)
        button1.clicked.connect(parent_window.set_first_step_player)
        button2.clicked.connect(parent_window.set_first_step_pc)
        button1.clicked.connect(self.close)
        button2.clicked.connect(self.close)


class App(QtWidgets.QMainWindow, mainwindow.Ui_MainWindow):
    dialog = None
    words = []

    def __init__(self, parent=None):
        super(App, self).__init__(parent)
        self.setupUi(self)
        self.setFixedSize(self.size())
        self.load_words()
        self.symbolLineEdit.textChanged.connect(self.check_symbol_text_edit)
        self.dialog = CustomDialog(self)
        self.dialog.show()
        self.wordLineEdit.setDisabled(True)
        self.wordLineEdit.setText("восхот")
        self.pushButton.clicked.connect(self.player_step)

    def load_words(self):
        with open(r"C:\Users\slein\Desktop\igra\app\slovar.txt", encoding="UTF-8") as file:
            self.words = file.read().split("\n")

    def check_word(self, word):
        if word in self.words:
            self.words.remove(word)
            return True
        return False

    def player_step(self):
        temp = list(self.wordLineEdit.text())
        temp[self.spinBox.value() - 1] = self.symbolLineEdit.text()
        new_word = ""
        for symbol in temp:
            new_word += symbol
        if self.check_word(new_word):
            self.wordLineEdit.setText(new_word)
            self.pc_step()

        else:
            self.infoLabel.setText("Нет такого слова")

    def pc_step(self):
        alphabet = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
        for char in alphabet:
            for i in range(5):
                temp = list(self.wordLineEdit.text())
                if temp[i] == char:
                    continue
                temp[i] = char
                new_word = ""
                for symbol in temp:
                    new_word += symbol
                if self.check_word(new_word):
                    self.infoLabel.setText(f"PC заменил  {self.wordLineEdit.text()} на {new_word}")
                    self.wordLineEdit.setText(new_word)
                    return
        self.infoLabel.setText("YOU WIN! Я не могу подобрать слово")
        self.groupBox.setDisabled(True)

    def set_first_step_pc(self):
        self.wordLineEdit.setText(self.words[random.randint(0, len(self.words))])

    def get_first_word(self):
        text, ok = QInputDialog.getText(self, 'Выбор слова',
                                        'Введите слово (слово должно быть в словаре):')
        return text

    def set_first_step_player(self):
        while True:
            word = self.get_first_word()
            if self.check_word(word):
                self.wordLineEdit.setText(word)
                self.pc_step()
                break

    def check_symbol_text_edit(self):
        if len(self.symbolLineEdit.text()) > 1:
            self.symbolLineEdit.setText(self.symbolLineEdit.text()[0])


def except_hook(except_type, value, t_back):
    QtWidgets.QMessageBox.critical(
        app, "CRITICAL ERROR", str(value),
        QtWidgets.QMessageBox.Cancel
    )

    sys.__excepthook__(except_type, value, t_back)


sys.excepthook = except_hook

app = QtWidgets.QApplication([])
window = App()
window.show()
app.exec_()
