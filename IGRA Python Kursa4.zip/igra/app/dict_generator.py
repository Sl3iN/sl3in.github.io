words = []


with open("C:\Users\slein\Desktop\igra\app\slovar.txt", "w", encoding="UTF-8") as file:
    temp = ""
    for word in words:
        temp += word + "\n"
    temp.rstrip("\n")
    file.write(temp)
